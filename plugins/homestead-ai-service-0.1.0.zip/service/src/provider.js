"use strict";

const ollama = require("./providers/ollama.js");
const openaiCompatible = require("./providers/openai-compatible.js");
const mock = require("./providers/mock.js");

const PROVIDERS = { ollama, "openai-compatible": openaiCompatible, mock };

function listEnvironment(value) {
  return String(value || "").split(",").map((entry) => entry.trim()).filter(Boolean);
}

function resolveSettings(requested = {}) {
  const defaultProvider = process.env.AI_PROVIDER || "ollama";
  const provider = String(requested.provider || defaultProvider).trim();
  const allowedProviders = listEnvironment(process.env.AI_ALLOWED_PROVIDERS || defaultProvider);
  if (!allowedProviders.includes(provider) || !PROVIDERS[provider]) {
    const error = new Error(`Model provider ${provider} is not allowed by this service.`);
    error.statusCode = 403;
    error.code = "PROVIDER_NOT_ALLOWED";
    throw error;
  }
  const model = String(requested.model || process.env.AI_MODEL || "").trim();
  if (!model) {
    const error = new Error("No AI model is configured.");
    error.statusCode = 503;
    error.code = "MODEL_NOT_CONFIGURED";
    throw error;
  }
  const allowedModels = listEnvironment(process.env.AI_ALLOWED_MODELS);
  if (allowedModels.length && !allowedModels.includes(model)) {
    const error = new Error(`Model ${model} is not in AI_ALLOWED_MODELS.`);
    error.statusCode = 403;
    error.code = "MODEL_NOT_ALLOWED";
    throw error;
  }
  return {
    provider,
    model,
    temperature: Math.max(0, Math.min(2, Number(requested.temperature ?? process.env.AI_TEMPERATURE ?? 0.2))),
    timeoutMs: Math.max(5000, Math.min(180000, Number(process.env.AI_PROVIDER_TIMEOUT_MS || 90000))),
    baseUrl: provider === "ollama" ? process.env.AI_OLLAMA_URL || "http://ollama:11434" : process.env.AI_OPENAI_BASE_URL || "",
    apiKey: provider === "openai-compatible" ? process.env.AI_OPENAI_API_KEY || "" : "",
  };
}

async function completeTurn(input, requested) {
  const settings = resolveSettings(requested);
  const result = await PROVIDERS[settings.provider].completeTurn(input, settings);
  return { ...result, provider: settings.provider, model: settings.model };
}

module.exports = { PROVIDERS, completeTurn, resolveSettings };
