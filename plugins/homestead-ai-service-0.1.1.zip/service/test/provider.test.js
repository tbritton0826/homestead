"use strict";

const test = require("node:test");
const assert = require("node:assert/strict");
const { resolveSettings } = require("../src/provider.js");

test("provider and model overrides remain allowlisted", () => {
  const previous = {
    AI_PROVIDER: process.env.AI_PROVIDER,
    AI_ALLOWED_PROVIDERS: process.env.AI_ALLOWED_PROVIDERS,
    AI_MODEL: process.env.AI_MODEL,
    AI_ALLOWED_MODELS: process.env.AI_ALLOWED_MODELS,
  };
  process.env.AI_PROVIDER = "mock";
  process.env.AI_ALLOWED_PROVIDERS = "mock";
  process.env.AI_MODEL = "test-model";
  process.env.AI_ALLOWED_MODELS = "test-model";
  assert.equal(resolveSettings({}).provider, "mock");
  assert.throws(() => resolveSettings({ provider: "ollama" }), /not allowed/);
  assert.throws(() => resolveSettings({ model: "different" }), /not in AI_ALLOWED_MODELS/);
  for (const [key, value] of Object.entries(previous)) {
    if (value === undefined) delete process.env[key];
    else process.env[key] = value;
  }
});
